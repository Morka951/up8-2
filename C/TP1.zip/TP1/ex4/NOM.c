#include <stdio.h>

int	main(void)
{
	printf("%s\n","GUEZ Ari - 22009789");
	return(0);
}
